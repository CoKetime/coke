const app = getApp();
var inputVal = '';
var msgList = [];
var ws, client_name = Math.random() * 50, client_header, client_id, room_id = '小仙女', client_list_data = {};
// 引入请求api
import { appRequest } from "../../utils/http.js"
import { webUrl } from "../../utils/http.js"
let chatInput = require('../../modules/chat-input/chat-input');
var util = require('../../utils/util.js');
function initData(that) {
  inputVal = '';

  msgList = [{
    speaker: 'server',
    contentType: 'text',
    content: '欢迎！',
    msg_type:'txt'
  },
  ]
  that.setData({
    msgList,
    inputVal
  })
}
Page({

  /**
   * 页面的初始数据
   */
  data: {

    socketOpen: false,
    wxchatLists: [],
    friendHeadUrl: '',
    // textMessage: '',
    chatItems: [],
    scrollTopTimeStamp: 0,
    height: 0,  //屏幕高度
    chatHeight: 0,//聊天屏幕高度
    normalDataTime: '',
  },
  //item的所有单向信息
  // {
  //     dataTime: '',//当前时间
  //     msg_type: '',//发送消息类型
  //     userImgSrc: '',//用户头像
  //     textMessage: '',//文字消息
  //     voiceSrc: '',//录音的路径
  //     voiceTime: 0,//录音的时长
  //     sendImgSrc: '',//图片路径
  //   }

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let _this = this;
    initData(this);
    _this.initData();
    //获取屏幕的高度
    wx.getSystemInfo({
      success(res) {
        _this.setData({
          height: wx.getSystemInfoSync().windowHeight,
          chatHeight: wx.getSystemInfoSync().windowHeight - 20
        })
      }
    })
    _this.webSocket();
  },
  initData: function () {
    let that = this;
    let systemInfo = wx.getSystemInfoSync();
    chatInput.init(this, {
      systemInfo: systemInfo,
      minVoiceTime: 1,
      maxVoiceTime: 60,
      startTimeDown: 56,
      format: 'mp3',//aac/mp3
      sendButtonBgColor: 'mediumseagreen',
      sendButtonTextColor: 'white',
      extraArr: [{
        picName: 'choose_picture',
        description: '照片'
      }, {
        picName: 'take_photos',
        description: '拍摄'
      }],
      // tabbarHeigth: 48
    });

    that.setData({
      pageHeight: systemInfo.windowHeight,
      normalDataTime: util.formatTime(new Date()),
    });
   
    that.textButton();
    that.extraButton();
    that.voiceButton();
  },
  textButton: function () {
    var that = this;
    chatInput.setTextMessageListener(function (e) {
      let content = e.detail.value;
      console.log(content);
      var list = that.data.wxchatLists;
      var temp = {
        userImgSrc: '../../image/chat/extra/close_chat.png',
        textMessage: content,
        dataTime: util.formatTime(new Date()),
        msg_type: 'text',
        type: 1
      };
      list.push(temp);
      that.setData({
        wxchatLists: list,
      })
    });

  },
  //发送语音
  voiceButton: function () {
    var that = this;
    chatInput.recordVoiceListener(function (res, duration) {
      let tempFilePath = res.tempFilePath;
      let vDuration = duration;
      console.log(tempFilePath);
      console.log(vDuration + "这是voice的时长");

      var list = that.data.wxchatLists;
      var temp = {
        'userImgSrc': '../../image/chat/extra/close_chat.png',
        'voiceSrc': tempFilePath,
        'voiceTime': vDuration,
        'dataTime': util.formatTime(new Date()),
        'type': 1,
        'to_client_id': 'all',
        'to_client_name': client_name,
        'form_client_id': client_id,
        'form_client_name': client_name,
        'room_id': room_id,
        'content': tempFilePath,
         msg_type: 'voice',
        'time': util.formatTime(new Date()),
      };
      that.sendUpload('Service/uploadvoice', temp, 'send');
      msgList.push({
        speaker: 'customer',
        contentType: 'text',
        content: temp,
        msg_type: 'voice'
      })
      inputVal = '';
      that.setData({
        msgList,
        inputVal,
      });
     
    });
    chatInput.setVoiceRecordStatusListener(function (status) {
      switch (status) {
        case chatInput.VRStatus.START://开始录音

          break;
        case chatInput.VRStatus.SUCCESS://录音成功

          break;
        case chatInput.VRStatus.CANCEL://取消录音

          break;
        case chatInput.VRStatus.SHORT://录音时长太短

          break;
        case chatInput.VRStatus.UNAUTH://未授权录音功能

          break;
        case chatInput.VRStatus.FAIL://录音失败(已经授权了)

          break;
      }
    })
  },
  extraButton: function () {
    let that = this;
    chatInput.clickExtraListener(function (e) {
      let itemIndex = parseInt(e.currentTarget.dataset.index);
      if (itemIndex === 2) {
        that.myFun();
        return;
      }
      wx.chooseImage({
        count: 1, // 默认9
        sizeType: ['compressed'],
        sourceType: itemIndex === 0 ? ['album'] : ['camera'],
        success: function (res) {
          let tempFilePath = res.tempFilePaths[0];
          console.log(tempFilePath);

          var list = that.data.wxchatLists;
          var temp = {
            'msg_type': 'img',
            'type': 1,
            'to_client_id': 'all',
            'to_client_name': client_name,
            'form_client_id': client_id,
            'form_client_name': client_name,
            'room_id': room_id,
            'content': tempFilePath,
            'time': util.formatTime(new Date()),
         
          };
          that.sendUploadimg('Service/uploadimg', temp, 'send');
          msgList.push({
            speaker: 'customer',
            contentType: 'text',
            content: tempFilePath,
            msg_type: 'img'
          })
          inputVal = '';
          that.setData({
            msgList,
            inputVal,
          });
        }
      });

    });
    chatInput.setExtraButtonClickListener(function (dismiss) {
      console.log('Extra弹窗是否消息', dismiss);
    })
  },


  resetInputStatus: function () {
    chatInput.closeExtraView();
  },

  //播放录音
  playRecord: function (e) {
    this.innerAudioContext = wx.createInnerAudioContext();
    　this.innerAudioContext.onError((res) => {
      　　　// 播放音频失败的回调
    　　　　})
    this.innerAudioContext.src = e.currentTarget.dataset.id; // 这里可以是录音的临时路径
    this.innerAudioContext.play()
  },

  //删除单条消息
  delMsg: function (e) {
    var that = this;
    var magIdx = parseInt(e.currentTarget.dataset.index);
    var list = that.data.wxchatLists;

    wx.showModal({
      title: '提示',
      content: '确定删除此消息吗？',
      success: function (res) {
        if (res.confirm) {
          console.log(e);
          list.splice(magIdx, 1);
          that.setData({
            wxchatLists: list,
          });
          // wx.showToast({
          //   title: '删除成功',
          //   mask: true,
          //   icon: 'none',
          // })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })



  },
  //点击图片 预览大图
  seeBigImg: function (e) {
    var that = this;
    var idx = parseInt(e.currentTarget.dataset.index);
    var src = that.data.wxchatLists[idx].sendImgSrc;
    wx.previewImage({
      current: src, // 当前显示图片的http链接
      urls: [src] // 需要预览的图片http链接列表
    })
  },
  /**
  * 生命周期函数--监听页面显示
  */
  onShow: function (e) {
    var that = this;
    if (!that.data.socketOpen) {
      this.webSocket()
    }

  },
  onReady: function () {
    var that = this;
    wx.onSocketOpen(function (res) {
      that.setData({
        socketOpen: true
      })
      console.log('监听 WebSocket 连接打开事件。', res)
    })
    wx.onSocketClose(function (res) {
      console.log('监听 WebSocket 连接关闭事件。', res)
      that.setData({
        socketOpen: false
      })
      that.webSocket()
    })
    wx.onSocketError(function (res) {
      console.log('监听 WebSocket 错误。错误信息', onError)
      that.setData({
        socketOpen: false
      })
    })
    wx.onSocketMessage(function (res) {
      var data = (JSON.parse(res.data));
      that.ws_message(data)
    })
  },
  //连接workerman
  webSocket: function () {
    var that = this;
    wx.connectSocket({
      url: 'ws://a.168map.cn:7272',
      data: '5',
      header: {
        'content-type': 'application/json'
      },
      method: 'post',
      success: function (res) {
        that.setData({
          socketOpen: true
        })
      },
      fail: function (err) {
        wx.showToast({
          title: '网络异常！',
        })
        console.log(333)
      },
    })

  },

  /**
   * 发送点击监听
   */
  sendClick: function (e) {
    var that = this;
    if (that.data.socketOpen) {
      var data = {
        'type': 'say',
        'to_client_id': 'all',
        'to_client_name': client_name,
        'form_client_id': client_id,
        'form_client_name': client_name,
        'room_id': room_id,
        'content': e.detail.value,
        'form_client_header': client_header,
        'time': util.formatTime(new Date()),
        msg_type: 'txt'
      }
      //群组。如私聊加判断url
      that.sendMessage('Service/sendGroupMsg', data, 'send')
      msgList.push({
        speaker: 'customer',
        contentType: 'text',
        content: e.detail.value,
        msg_type:'txt'
      })
      inputVal = '';
      that.setData({
        msgList,
        inputVal,
        textMessage:''
      });
    }

  },
  //发送信息
  sendMessage: function (url, data, type) {
    appRequest({
      url: url,
      param: data,
      method: "POST",
      success: function (data) {

      },
      fail: function (res) {
        wx.showModal({
          title: '系统繁忙',
          showCancel: false
        })
      }
    })
  },

//上传语音
  sendUpload: function (url, data, type){
    wx.uploadFile({
      url: webUrl + url, //仅为示例，非真实的接口地址
      filePath: data.voiceSrc,
      name: 'file',
      formData: {
        'voiceTime': data.voiceTime,
        'type': 1,
        'to_client_id': 'all',
        'to_client_name': client_name,
        'form_client_id': client_id,
        'form_client_name': client_name,
        'room_id': room_id,
         'msg_type': 'voice',
        'time': util.formatTime(new Date()),
      },
      success(res) {
        const data = res.data
        //do something
      }
    })
  },
  //上传图片自行封装
  sendUploadimg: function (url, data, type) {
    wx.uploadFile({
      url: webUrl + url, //仅为示例，非真实的接口地址
      filePath: data.content,
      name: 'file',
      formData: {
        'type': 1,
        'to_client_id': 'all',
        'to_client_name': client_name,
        'form_client_id': client_id,
        'form_client_name': client_name,
        'room_id': room_id,
        'msg_type': 'img',
        'time': util.formatTime(new Date()),
      },
      success(res) {
        const data = res.data
        //do something
      }
    })
  },
  //点击图片 预览大图
  seeBigImg: function (e) {
    var that = this;
    var idx = parseInt(e.currentTarget.dataset.index);
    var src = that.data.msgList[idx].content;
    wx.previewImage({
      current: src, // 当前显示图片的http链接
      urls: [src] // 需要预览的图片http链接列表
    })
  },
  /*
  *接收来自socket服务器的信息
  */
  ws_message: function (msg) {
    console.log(msg);
    var that = this;
    //var data = JSON.parse(msg.data);
    switch (msg.type) {
      //初始化,绑定,发送房间号
      case 'init':
        client_id = msg.client_id;
        var sendMsg = {
          'type': 'bind',
          'client_id': client_id,
          'client_name': client_name,
          'room_id': room_id,
          'time': util.formatTime(new Date()),
          
        };
        that.sendMessage('Service/bindUid', sendMsg, 'bind');
        break;
      //接收房间或私聊发来的信息
      case 'say':
        that.updateMsgList(msg.to_client_id, msg.to_client_name, msg.form_client_name, msg.content, msg.time, msg.msg_type, msg.longtime);
        break;
    }
  },
  updateMsgList: function (to_client_id, to_client_name, form_client_name, content, time, msg_type, longtime) {
    console.log(msg_type);
    var that = this;
    if (to_client_id == 'all') {
      if (msg_type === 'txt') {
        msgList.push({
          speaker: 'server',
          contentType: 'text',
          content: content,
          msg_type: msg_type
        })
        inputVal = '';
        that.setData({
          msgList,
          inputVal
        });
      }else if(msg_type === 'voice'){
        msgList.push({
          speaker: 'server',
          contentType: 'text',
          content: content,
          msg_type: msg_type,
          longtime:longtime
        })
        inputVal = '';
        that.setData({
          msgList,
          inputVal
        });
      } else if (msg_type === 'img') {
        msgList.push({
          speaker: 'server',
          contentType: 'text',
          content: content,
          msg_type: msg_type,
        })
        inputVal = '';
        that.setData({
          msgList,
          inputVal
        });
      }
    }
  },
});