var voice = "";
Page({
  play: function () {
    console.log(voice);
  },
  start: function () {
    //开始录音  
    wx.startRecord({
      success: function (e) {
        voice = e.tempFilePath
      }
    })
   
  },
  stop: function () {
    //结束录音  
    wx.stopRecord();
  }
})
